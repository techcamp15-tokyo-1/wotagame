//
//  PlayLayer.h
//  wotagame
//
//  Created by KikruaYuichirou on 2013/08/21.
//  Copyright 2013年 wotagineer. All rights reserved.
//
//	ゲームの実行ビュー

#import "cocos2d.h"
#import "CCTouchDispatcher.h"

#import "PlayController.h"

@interface PlayLayer : CCLayer {
}

+(CCScene *) scene;

@end
