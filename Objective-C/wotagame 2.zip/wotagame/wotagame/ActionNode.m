//
//  ActionNode.m
//  wotagame
//
//  Created by KikruaYuichirou on 2013/08/22.
//  Copyright (c) 2013年 wotagineer. All rights reserved.
//

#import "ActionNode.h"

@implementation ActionNode
static NSMutableArray *AllNodeList;	//すべてのノード

+(void) initialize {
	AllNodeList = [[NSMutableArray alloc] init];
}

+(void) addNode:(NSString *)value atBeat:(float)beat withType:(enum NODETYPE)type {
	ActionNode *node = [[ActionNode alloc] init];
	node.value = value;
	node.beat = beat;
	node.type = type;
	node.isShowed = NO;
	[AllNodeList addObject:node];
}

//ノードを初期化
+(void) resetNodeIsShowed {
	for (ActionNode *node in AllNodeList) {
		node.isShowed = NO;
	}
}

//現在のノードから先を指定した拍分取得する。
+(NSMutableArray *) getFutureNodesAtBeat:(float)beat andDurationfrom:(float)durationBefore to:(float)durationAfter{
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	ActionNode *node;
	
	for (int i = 0; i < [AllNodeList count]; i++) {
		node = AllNodeList[i];
		if (!node) continue;
		if (node.beat - beat > durationAfter) return arr;
		if (beat - node.beat < durationBefore) {
			[arr addObject:node];
		}
	}
	return arr;
}

@end
